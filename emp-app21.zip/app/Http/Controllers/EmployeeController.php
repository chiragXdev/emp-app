<?php

namespace App\Http\Controllers;

use App\Http\Resources\EmployeeResource;
use App\Models\Employee;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\DataTables;

class EmployeeController extends Controller
{


    public function index(Request $request)
    {
        if ($request->ajax()) {
            $perPage = $request->get('per_page', 10);
            $employees = Employee::paginate($perPage);
            return EmployeeResource::collection($employees);
        }

        return view('employees.index');
    }

    public function show($id)
    {
        $employee = Employee::findOrFail($id);
        return response()->json($employee);
    }



    public function store(Request $request)
    {
        // Define validation rules
        $validatedData = $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'joining_date' => 'nullable',
            'profile_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Handle the file upload
        if ($request->hasFile('profile_image')) {
            $file = $request->file('profile_image');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/profile_images', $filename);

            $validatedData['profile_image'] = $filename;
        }

        $employee = Employee::create($validatedData);

        // Return a response or redirect
        return response()->json($employee, 201); // Return the newly created employee
    }

    public function update(Request $request, $id)
    {
        // Find the employee by ID or fail
        $employee = Employee::findOrFail($id);

        // Define validation rules
        $validatedData = $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'joining_date' => 'nullable|date',
            'profile_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Handle the file upload
        if ($request->hasFile('profile_image')) {
            // Delete the old profile image if it exists
            if ($employee->profile_image) {
                Storage::delete('public/profile_images/' . $employee->profile_image);
            }

            $file = $request->file('profile_image');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/profile_images', $filename);

            $validatedData['profile_image'] = $filename;
        }

        // Update the employee with the validated data
        $employee->update($validatedData);

        // Return a response
        return response()->json($employee, 200); // Return the updated employee
    }
    public function destroy($id)
    {
        // Find the employee by ID or fail
        $employee = Employee::findOrFail($id);

        // Delete the profile image if it exists
        if ($employee->profile_image) {
            Storage::delete('public/profile_images/' . $employee->profile_image);
        }

        // Delete the employee record
        $employee->delete();

        // Return a response
        return response()->json(['message' => 'Employee deleted successfully.'], 200);
    }




}
