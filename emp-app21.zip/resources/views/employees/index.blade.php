<x-layout>


    <div class="relative p-3 overflow-x-auto shadow-md sm:rounded-lg">
        <div class="flex items-center justify-between">
            <div
                class="flex items-center justify-between flex-column md:flex-row flex-wrap space-y-4 md:space-y-0 py-4 bg-white">
                <button id="btn-add-emp" data-modal-target="empModal" data-modal-toggle="empModal"
                    class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                    type="button" title="Add Employee">
                    Add
                </button>
            </div>

            <div
                class="flex items-center justify-between flex-column md:flex-row flex-wrap space-y-4 md:space-y-0 py-4 bg-white">

                <label for="table-search" class="sr-only">Search</label>
                <div class="relative">
                    <div class="absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none">
                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
                        </svg>
                    </div>
                    <input type="text" id="table-search-users"
                        class="block pt-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Search for users">
                </div>
            </div>
        </div>


        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">Emp. Code</th>
                    <th scope="col" class="px-6 py-3">Profile Image</th>
                    <th scope="col" class="px-6 py-3">Full Name</th>
                    <th scope="col" class="px-6 py-3">Joining Date</th>
                    <th scope="col" class="px-6 py-3">Actions</th>

                </tr>
            </thead>
            <tbody id="employee-table-body">
            </tbody>
        </table>

    </div>


    <div id="pagination-links" class="mt-4">

    </div>

    <x-emp.modal-form />

</x-layout>
<script type="module">
    $(document).ready(function() {
        const $targetEl = document.getElementById('empModal');

        // Modal options with default values
        const options = {
            placement: 'bottom-right',
            backdrop: 'static',
            backdropClasses: 'bg-gray-900/50 dark:bg-gray-900/80 fixed inset-0 z-40',
            closable: true,
            onHide: () => {

                $('#add-employee-form').trigger('reset');
                console.log('modal is hidden');
            },
            onShow: () => {
                console.log('modal is shown');
            },
            onToggle: () => {
                console.log('modal has been toggled');
            },
        };

        // Instance options object
        const instanceOptions = {
            id: 'empModal',
            override: true
        };

        const modal = new Modal($targetEl, options, instanceOptions);

        // Function to load employees and handle pagination
        function loadEmployees(page) {
            $.ajax({
                url: '/api/employees?page=' + page,
                success: function(response) {
                    console.log(response.meta.links); // Debugging: Inspect the links data

                    // Generate table rows
                    var rows = '';
                    var editButtonSvg = `<svg class="w-6 h-6 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.779 17.779 4.36 19.918 6.5 13.5m4.279 4.279 8.364-8.643a3.027 3.027 0 0 0-2.14-5.165 3.03 3.03 0 0 0-2.14.886L6.5 13.5m4.279 4.279L6.499 13.5m2.14 2.14 6.213-6.504M12.75 7.04 17 11.28"/>
                        </svg>
                        `;
                    var trashButtonSvg = `<svg class="w-6 h-6 text-red" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                            <path fill-rule="evenodd" d="M8.586 2.586A2 2 0 0 1 10 2h4a2 2 0 0 1 2 2v2h3a1 1 0 1 1 0 2v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V8a1 1 0 0 1 0-2h3V4a2 2 0 0 1 .586-1.414ZM10 6h4V4h-4v2Zm1 4a1 1 0 1 0-2 0v8a1 1 0 1 0 2 0v-8Zm4 0a1 1 0 1 0-2 0v8a1 1 0 1 0 2 0v-8Z" clip-rule="evenodd"/>
                            </svg>
                            `;
                    $.each(response.data, function(index, employee) {
                        rows += `<tr>
                        <td class="px-6 py-4">${employee.id}</td>
                        <td class="px-6 py-4">
                            ${employee.profile_image ?
                                `<img src="/storage/profile_images/${employee.profile_image}" alt="Profile Image" class="w-16 h-16 rounded-full object-cover" />` :
                                'N/A'}
                        </td>
                        <td class="px-6 py-4">${employee.first_name} ${employee.last_name}</td>
                        <td class="px-6 py-4">${employee.joining_date ? employee.joining_date : 'N/A'}</td>
                        <td class="px-6 py-4 flex">
                            <a href="#" class="edit-employee-link text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm p-2 me-2 mb-2" data-id="${employee.id}" title="Edit Employee">${editButtonSvg}</a>
                            <a href="#" class="delete-employee-link text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm p-2 me-2 mb-2" data-id="${employee.id}" title="Delete Employee">${trashButtonSvg}</a>
                        </td>
                    </tr>`;
                    });

                    $('#employee-table-body').html(rows);

                    // Generate pagination links
                    var pagination =
                        '<nav aria-label="Page navigation example"><ul class="inline-flex -space-x-px text-base h-10">';

                    // Previous Page Link
                    if (response.meta.current_page > 1) {
                        pagination += '<li>' +
                            '<a href="#" data-page="' + (response.meta.current_page - 1) +
                            '" class="flex items-center justify-center px-4 h-10 ms-0 leading-tight text-gray-500 bg-white border border-e-0 border-gray-300 rounded-s-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">Previous</a>' +
                            '</li>';
                    }

                    // Page Links
                    $.each(response.meta.links, function(index, link) {
                        if (link.url) {
                            var pageNumber = link.url.split('page=')[1];
                            pagination += '<li>' +
                                '<a href="#" data-page="' + pageNumber +
                                '" class="flex items-center justify-center px-4 h-10 leading-tight ' +
                                (link.active ?
                                    'text-blue-600 border border-gray-300 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 dark:border-gray-700 dark:bg-gray-700 dark:text-white' :
                                    'text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white'
                                ) +
                                '">' + link.label + '</a></li>';
                        }
                    });

                    // Next Page Link
                    if (response.meta.current_page < response.meta.last_page) {
                        pagination += '<li>' +
                            '<a href="#" data-page="' + (response.meta.current_page + 1) +
                            '" class="flex items-center justify-center px-4 h-10 leading-tight text-gray-500 bg-white border border-gray-300 rounded-e-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">Next</a>' +
                            '</li>';
                    }

                    pagination += '</ul></nav>';
                    $('#pagination-links').html(pagination);
                }
            });
        }

        // Initialize on page load
        loadEmployees(1);

        // Handle Add Employee button click
        $('#btn-add-emp').on('click', function() {
            showAddEmployeeModal();
        });

        // Handle Add Employee form submission
        function handleAddEmployeeFormSubmit(e) {
            e.preventDefault(); // Prevent the default form submission

            var formData = new FormData(this);

            $.ajax({
                url: '/api/employees', // Adjust the URL to your endpoint
                type: 'POST',
                data: formData,
                contentType: false, // Set contentType to false when sending FormData
                processData: false, // Prevent jQuery from automatically processing the data
                success: function(response) {
                    console.log('Employee added successfully:', response);
                    modal.hide(); // Hide the modal
                    loadEmployees(1); // Reload the employees
                },
                error: function(xhr) {
                    console.error('Error adding employee:', xhr.responseText);
                    showToast('Error adding employee: ' + xhr.responseText);
                }
            });
        }

        // Handle Edit Employee button click
        function handleEditEmployeeClick(e) {
            e.preventDefault();
            var employeeId = $(this).data('id');

            $.ajax({
                url: '/api/employees/' + employeeId,
                success: function(employee) {
                    $('#first_name').val(employee.first_name);
                    $('#last_name').val(employee.last_name);
                    $('#joining_date').val(employee.joining_date);
                    $('#emp-modal-title').text('Edit Employee');
                    $('#employee-form').attr('id', 'edit-employee-form').attr('data-id', employee
                        .id);
                    modal.show(); // Show the modal
                }
            });
        }

        // Handle Edit Employee form submission
        function handleEditEmployeeFormSubmit(e) {
            e.preventDefault();

            var employeeId = $(this).data('id');
            var formData = new FormData(this);

            $.ajax({
                url: '/api/employees/' + employeeId,
                type: 'PUT',
                data: formData,
                contentType: false, // Set contentType to false when sending FormData
                processData: false, // Prevent jQuery from automatically processing the data
                success: function(response) {
                    console.log('Employee updated successfully:', response);
                    modal.hide(); // Hide the modal
                    loadEmployees(1); // Reload the employee list
                },
                error: function(xhr) {
                    console.error('Error updating employee:', xhr.responseText);
                    showToast('Error updating employee: ' + xhr.responseText);
                }
            });
        }

        // Handle Delete Employee button click
        function handleDeleteEmployeeClick(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this employee?')) {
                var employeeId = $(this).data('id');

                $.ajax({
                    url: '/api/employees/' + employeeId,
                    type: 'DELETE',
                    success: function(response) {
                        console.log('Employee deleted successfully:', response);
                        loadEmployees(1); // Reload the employee list
                    },
                    error: function(xhr) {
                        console.error('Error deleting employee:', xhr.responseText);
                        showToast('Error deleting employee: ' + xhr.responseText);
                    }
                });
            }
        }

        // Handle pagination link clicks
        function handlePaginationClick(e) {
            e.preventDefault();
            var page = $(this).data('page');
            if (page) {
                loadEmployees(page);
            }
        }

        // Function to show the Add Employee modal
        function showAddEmployeeModal() {

            $('#add-employee-form').trigger('reset');
            $('#emp-modal-title').text('Add Employee');
            $('#employee-form').attr('id', 'add-employee-form');
            modal.show(); // Show the modal
        }

        // Handle Add Employee form submission
        $(document).on('submit', '#add-employee-form', handleAddEmployeeFormSubmit);

        // Handle Edit Employee button click
        $(document).on('click', '.edit-employee-link', handleEditEmployeeClick);

        // Handle Edit Employee form submission
        $(document).on('submit', '#edit-employee-form', handleEditEmployeeFormSubmit);

        // Handle Delete Employee button click
        $(document).on('click', '.delete-employee-link', handleDeleteEmployeeClick);

        // Handle pagination link clicks
        $(document).on('click', '#pagination-links a', handlePaginationClick);

        // Handle modal close
        $(document).on('click', '[data-modal-hide="empModal"]', function() {
            modal.hide(); // Hide the modal
        });
    });
</script>



{{-- Toasts --}}
<div id="toast-top-right"
    class="fixed flex items-center w-full max-w-xs p-4 space-x-4 text-gray-500 bg-white divide-x rtl:divide-x-reverse divide-gray-200 rounded-lg shadow top-5 right-5 dark:text-gray-400 dark:divide-gray-700 dark:bg-gray-800"
    role="alert" style="display: none;">
    <div class="text-sm font-normal">Top right positioning.</div>
</div>
