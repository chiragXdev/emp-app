<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;

class EmployeeController extends Controller
{
    public function index(Request $request)
    {
        $employees = Employee::paginate(15);

        if (request()->ajax()) {
            return response()->json($employees);
        }
        $perPage = 15; // Number of records per page
        $page = $request->input('page', 1);
        $skip = ($page - 1) * $perPage;

        // MongoDB-specific query
        $employees = Employee::skip($skip)->limit($perPage)->get();
        $total = Employee::count();

        if ($request->ajax()) {
            return response()->json([
                'data' => $employees,
                'current_page' => $page,
                'last_page' => ceil($total / $perPage),
                'total' => $total
            ]);
        }

        return view('employees.index');
    }
    public function indexx()
    {
        // for ($i = 0; $i < 50; $i++) {

        //     Employee::create([
        //         'emp_code' => 'EMP-00' . $i + 1,
        //         'first_name' => 'fn' . $i,
        //         'last_name' => 'ln' . $i,
        //         'joining_date' => Carbon::now(),
        //         'profile_image' => null,

        //     ]);
        // }

        $employees = Employee::paginate(15);

        if (request()->ajax()) {
            return response()->json($employees);
        }


        return view('employees.index', [
            'employees' => $employees
        ]);
    }
    public function indexYAJ(Request $request)
    {
        if ($request->ajax()) {
            $employees = Employee::select(['first_name', 'last_name', 'joining_date']);

            return DataTables::of($employees)
                ->make(true); // Automatically handles pagination, sorting, and filtering
        }

        // For non-AJAX requests, return the default view
        return view('employees.index');
    }

    public function store()
    { // Employee::create([
        //     'name' => 'ABC',
        //     'age' => 19,

        // ]);
        dd('store cl');
    }
}
