<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    



    <table id="default-table">

    </table>
    <div id="pagination"></div>

    <script type="module">
        let currentPage = 1;
        let dataTable;

        $(document).ready(function() {
            loadTableData(currentPage);

            // Event listener for pagination buttons
            $('#pagination').on('click', 'a', function(e) {
                e.preventDefault();
                const page = $(this).attr('data-page');
                if (page) {
                    currentPage = page;
                    loadTableData(currentPage);
                    history.pushState(null, '',
                        `?page=${page}`); // Update the URL without reloading the page
                }
            });
        });

        function loadTableData(page) {
            $.ajax({
                url: "<?php echo e(route('employees')); ?>",
                method: 'GET',
                data: {
                    page: page
                }, // Send the page number as a query parameter
                success: function(response) {
                    updateTable(response.data);
                    updatePagination(response.current_page, response.last_page, response.links);
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching data:', error);
                }
            });
        }

        function updateTable(data) {
            // Destroy the previous instance of simpleDatatables (if it exists)
            if (dataTable) {
                dataTable.destroy();
            }

            // Reinitialize the table with new data
            dataTable = new simpleDatatables.DataTable("#default-table", {
                data: {
                    headings: ["First Name", "Last Name", "Joining Date"],
                    data: data.map(employee => [
                        employee.first_name,
                        employee.last_name,
                        employee.joining_date.length ? employee.joining_date : 'N/A'
                    ])
                },
                perPageSelect: false,
                searchable: true
            });
        }

        function updatePagination(currentPage, lastPage, links) {
            let paginationHtml = '';

            links.forEach(link => {
                paginationHtml +=
                    `<a href="#" data-page="${getPageFromUrl(link.url)}" class="${link.active ? 'active' : ''}">${link.label}</a>`;
            });

            $('#pagination').html(paginationHtml);
        }

        function getPageFromUrl(url) {
            const params = new URLSearchParams(url.split('?')[1]);
            return params.get('page');
        }
    </script>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\emp-app\resources\views/employees/index.blade.php ENDPATH**/ ?>