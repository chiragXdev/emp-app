import "./bootstrap";
import "flowbite";

import DataTable from "datatables.net-dt";

// let table = new DataTable("#myTable");
